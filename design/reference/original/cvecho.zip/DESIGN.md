# Sahara — Warm Minimalism

## North Star: "Sun-Baked Simplicity"
Luxurious warmth meets disciplined minimalism. Golden tones, editorial serif headings, and abundant whitespace.

## Colors
- **Primary (`#c2652a`):** Burnt sienna — warm, earthy CTAs and focus states.
- **Background (`#faf5ee`):** Warm linen — never cold white.
- **Tertiary (`#8c3c3c`):** Dusty rose — sparse accent for emphasis.
- Entire palette is warm-shifted. Even grays have warm undertones.

## Typography
- **Headlines:** EB Garamond — elegant, editorial serif. Large sizes with tight leading.
- **Body/Labels:** Manrope — geometric sans-serif, clean and modern contrast to the serif.
- The serif/sans pairing creates a luxury editorial feel.

## Elevation
- Ultra-soft shadows: `0 2px 16px rgba(58, 48, 42, 0.04)`. Barely visible.
- Prefer warm background tinting for hierarchy.
- Borders: thin and warm (`#d8d0c8` at 60% opacity).

## Components
- **Buttons:** Primary = solid sienna fill, 8px radius. Secondary = outlined with warm border. Text links underlined on hover.
- **Cards:** Warm white or `surface_container_low`, generous padding (28-32px). Minimal borders.
- **Inputs:** White background, warm gray border, sienna focus state.

## Rules
- Whitespace is the primary design tool. When in doubt, add more.
- Content should feel curated, not cluttered. Limit items per section.
- Photography should be warm-toned. Avoid cool/blue stock imagery.